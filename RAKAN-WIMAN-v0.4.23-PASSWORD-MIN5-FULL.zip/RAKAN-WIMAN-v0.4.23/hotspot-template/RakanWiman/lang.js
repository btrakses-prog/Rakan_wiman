(function () {
  'use strict';

  var storageKey = 'rw_hotspot_language';
  var allowed = ['id', 'en'];

  function readLanguage() {
    try {
      var saved = localStorage.getItem(storageKey);
      if (allowed.indexOf(saved) !== -1) return saved;
    } catch (error) {
      // Storage may be unavailable in restricted captive-portal browsers.
    }
    return 'id';
  }

  function applyLanguage(language) {
    var lang = allowed.indexOf(language) !== -1 ? language : 'id';
    document.documentElement.lang = lang;

    document.querySelectorAll('[data-i18n-id][data-i18n-en]').forEach(function (element) {
      var value = lang === 'en' ? element.getAttribute('data-i18n-en') : element.getAttribute('data-i18n-id');
      if (value !== null) element.textContent = value;
    });

    document.querySelectorAll('[data-placeholder-id][data-placeholder-en]').forEach(function (element) {
      element.setAttribute('placeholder', lang === 'en' ? element.getAttribute('data-placeholder-en') : element.getAttribute('data-placeholder-id'));
    });

    document.querySelectorAll('[data-aria-id][data-aria-en]').forEach(function (element) {
      element.setAttribute('aria-label', lang === 'en' ? element.getAttribute('data-aria-en') : element.getAttribute('data-aria-id'));
    });

    var passwordField = document.getElementById('rw-password');
    var passwordButton = document.querySelector('.show-password');
    if (passwordField && passwordButton) {
      var visible = passwordField.type !== 'password';
      passwordButton.textContent = visible ? (lang === 'en' ? 'Hide' : 'Sembunyikan') : (lang === 'en' ? 'Show' : 'Lihat');
      passwordButton.setAttribute('aria-label', visible ? (lang === 'en' ? 'Hide password' : 'Sembunyikan password') : (lang === 'en' ? 'Show password' : 'Tampilkan password'));
    }

    document.querySelectorAll('[data-lang]').forEach(function (button) {
      var active = button.getAttribute('data-lang') === lang;
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', active ? 'true' : 'false');
    });

    try { localStorage.setItem(storageKey, lang); } catch (error) {
      // The selected language still applies to the current page without storage.
    }
  }

  window.rwCurrentLanguage = function () {
    return document.documentElement.lang === 'en' ? 'en' : 'id';
  };
  window.rwApplyLanguage = applyLanguage;

  document.addEventListener('click', function (event) {
    var button = event.target.closest('[data-lang]');
    if (!button) return;
    applyLanguage(button.getAttribute('data-lang'));
  });

  applyLanguage(readLanguage());
})();
