# Template Login HotSpot RAKAN WIMAN

Direktori `RakanWiman/` berisi captive portal mandiri untuk MikroTik HotSpot (login, failed-login, alogin, status, logout, error, dan redirect). File ini merupakan karya khusus RAKAN WIMAN dan tidak membutuhkan lisensi N-STORE. Lihat `../docs/WALLED-GARDEN.md` untuk proses pengunggahan dan konfigurasi akses portal pembelian.

## Bahasa antarmuka

Template HotSpot mendukung Bahasa Indonesia dan English. Pilihan bahasa tersedia pada halaman login, status, logout, informasi login, dan autentikasi berhasil; pilihan disimpan pada browser perangkat agar tetap digunakan saat berpindah halaman. Bahasa default adalah Indonesia.
