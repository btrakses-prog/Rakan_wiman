# RAKAN WIMAN v0.4.23

RAKAN WIMAN adalah aplikasi mandiri untuk pengelolaan HotSpot MikroTik, voucher, profil HotSpot, pembayaran ViaQRIS dinamis, dan notifikasi WhatsApp.

## Pembaruan v0.4.23

### Tema modern elegan dan dua bahasa
- Memperbarui tampilan panel dengan palet midnight navy, indigo, dan teal, kartu yang lebih halus, navigasi yang lebih jelas, serta perapian responsif untuk desktop dan perangkat mobile.
- Menambahkan pemilih bahasa Indonesia / English pada panel admin, halaman login, portal pembelian dan pembayaran, serta halaman captive portal HotSpot (login, status, logout, dan informasi koneksi).
- Bahasa panel dan portal web disimpan dalam sesi pengguna; captive portal MikroTik menyimpan pilihan bahasa pada browser menggunakan localStorage.
- Bahasa default tetap Bahasa Indonesia. Tidak ada perubahan skema database atau migration.

## Pembaruan v0.4.21

### Dashboard — User HotSpot Aktif
- Menambahkan kartu **User Hotspot Aktif** pada ringkasan dashboard.
- Jumlah sesi dibaca langsung dari `/ip/hotspot/active/print` pada setiap router aktif yang terdaftar di RAKAN WIMAN.
- Multi-router dijumlahkan; panel rincian menampilkan jumlah sesi per router dan status keberhasilan pembacaan.
- Rincian sesi dapat dibuka untuk melihat username, IP, MAC, HotSpot Server, uptime, serta trafik upload/download.
- Jika sebagian router gagal dibaca, dashboard memberi status **Data sebagian** dan hanya menampilkan jumlah dari router yang berhasil dibaca. Jika seluruh router gagal, kartu menampilkan tanda `—`, bukan angka nol yang menyesatkan.
- Data sesi tidak disimpan sebagai data voucher dan tidak memengaruhi masa aktif atau status pelanggan.
- Pemeriksaan dilakukan saat dashboard dibuka atau saat tombol **Perbarui** ditekan. Tidak ada polling latar belakang.
- Timeout monitoring dibuat singkat agar satu router yang tidak dapat dijangkau tidak menahan dashboard terlalu lama.

## Instalasi baru (paket FULL)
1. Ekstrak seluruh folder proyek ke hosting.
2. Arahkan Document Root ke folder `public` atau gunakan mode subfolder sesuai `docs/INSTALL.md`.
3. Buat database MySQL/MariaDB kosong dan user database.
4. Buka `/install` lalu ikuti Web Installer. Installer menjalankan migration `001` sampai `008`, membuat akun Superadmin, serta menghasilkan `.env` dan `APP_KEY` baru.
5. Setelah instalasi selesai, pastikan `public/install.php` sudah terhapus atau hapus manual jika hosting tidak mengizinkannya.
6. Lanjutkan konfigurasi router, paket, ViaQRIS, WhatsApp, dan cron.

**Penting:** paket FULL ini untuk instalasi baru pada database kosong. Jangan gunakan backup database lama sebagai baseline instalasi baru. Untuk aplikasi yang sudah berjalan, gunakan prosedur upgrade dan pertahankan `.env`, `APP_KEY`, serta `storage`.

## Catatan
- Akun API MikroTik harus memiliki hak `read` untuk menu HotSpot Active.
- Satu baris pada `/ip/hotspot/active` dihitung sebagai satu sesi aktif. Jika satu username terhubung melalui beberapa perangkat/router, setiap sesi dihitung.
- Jika router offline, tidak dapat diautentikasi, atau tidak memiliki izin membaca HotSpot Active, router tersebut ditandai gagal dan tidak dimasukkan ke total.
- Dashboard membaca data live; hasilnya bukan jumlah voucher yang dibuat maupun jumlah pelanggan terdaftar.


## Perapian paket v0.4.21
- Merapikan stylesheet utama dan meningkatkan responsivitas panel pada layar tablet/ponsel.
- Menambahkan backdrop menu navigasi mobile dan memperbaiki aksesibilitas tombol menu.
- Memindahkan CSS log dashboard ke stylesheet utama.
- Menghapus catatan penghapusan file legacy yang sudah tidak ada di paket.
- Menyelaraskan Web Installer dan dokumentasi agar memvalidasi serta menjelaskan migration `001`–`008`.
- Seluruh modul aplikasi, template HotSpot, dan migration dipertahankan.
