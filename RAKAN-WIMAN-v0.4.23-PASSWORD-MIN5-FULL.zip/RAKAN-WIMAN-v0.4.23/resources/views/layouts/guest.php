<?php
use function RakanWiman\Core\e;
use function RakanWiman\Core\t;
use function RakanWiman\Core\current_language;
use function RakanWiman\Core\language_url;
$lang = current_language();
?>
<!doctype html><html lang="<?= e($lang) ?>"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#101a2d"><title><?= e(t($title ?? 'RAKAN WIMAN')) ?> · RAKAN WIMAN</title><base href="<?= e(rtrim(getenv('APP_URL') ?: '', '/') . '/') ?>"><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet"><link href="assets/app.css" rel="stylesheet"></head><body class="guest-bg"><nav class="guest-language"><a class="<?= $lang==='id'?'active':'' ?>" href="<?= e(language_url('id')) ?>">ID</a><a class="<?= $lang==='en'?'active':'' ?>" href="<?= e(language_url('en')) ?>">EN</a></nav><main class="container min-vh-100 d-flex align-items-center justify-content-center py-4"><div class="card border-0 shadow-lg auth-card"><div class="card-body p-4 p-md-5"><div class="text-center mb-4"><div class="brand-mark mx-auto mb-3">RW</div><h3 class="fw-bold mb-1">RAKAN WIMAN</h3><div class="text-secondary small">HOTSPOT & NETWORK MANAGEMENT</div></div><?= $content ?></div></div></main></body></html>
