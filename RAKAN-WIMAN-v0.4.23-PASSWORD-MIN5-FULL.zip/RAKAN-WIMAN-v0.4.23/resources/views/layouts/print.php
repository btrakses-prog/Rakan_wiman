<?php
use function RakanWiman\Core\e;
use function RakanWiman\Core\t;
use function RakanWiman\Core\current_language;
?>
<!doctype html>
<html lang="<?= e(current_language()) ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e(t($title ?? 'Cetak Voucher')) ?> · RAKAN WIMAN</title>
</head>
<body>
<?= $content ?>
</body>
</html>
