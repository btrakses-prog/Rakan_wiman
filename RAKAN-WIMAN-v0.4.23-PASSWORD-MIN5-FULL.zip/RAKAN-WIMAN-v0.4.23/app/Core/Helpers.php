<?php
declare(strict_types=1);
namespace RakanWiman\Core;

function e(?string $value): string { return htmlspecialchars($value ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function url(string $path = ''): string { return rtrim(getenv('APP_URL') ?: '', '/') . '/' . ltrim($path, '/'); }
function redirect(string $path): never { header('Location: ' . url($path)); exit; }
function csrf_token(): string { if (empty($_SESSION['_csrf'])) $_SESSION['_csrf'] = bin2hex(random_bytes(32)); return $_SESSION['_csrf']; }
function csrf_field(): string { return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">'; }
function verify_csrf(): void { if (!hash_equals($_SESSION['_csrf'] ?? '', $_POST['_csrf'] ?? '')) { http_response_code(419); exit('Sesi formulir kedaluwarsa. Muat ulang halaman.'); } }
function flash(string $key, ?string $value = null): ?string { if ($value !== null) { $_SESSION['_flash'][$key] = $value; return null; } $v = $_SESSION['_flash'][$key] ?? null; unset($_SESSION['_flash'][$key]); return $v; }

function current_language(): string
{
    $lang = $_SESSION['_rw_language'] ?? 'id';
    return in_array($lang, ['id', 'en'], true) ? $lang : 'id';
}

function t(string $text): string
{
    if (current_language() !== 'en') return $text;
    static $dictionary = null;
    if ($dictionary === null) {
        $file = dirname(__DIR__, 2) . '/resources/lang/en.php';
        $dictionary = is_file($file) ? (require $file) : [];
    }
    return strtr($text, $dictionary);
}

function translate_markup(string $html): string
{
    if (current_language() !== 'en' || $html === '') return $html;

    // Keep JavaScript and CSS untouched; translate rendered text and common UI attributes only.
    $protected = [];
    $html = preg_replace_callback('~<(script|style)\\b[^>]*>.*?</\\1>~is', static function (array $m) use (&$protected): string {
        $token = "\x1ARWPROTECTED" . count($protected) . "\x1A";
        $protected[$token] = $m[0];
        return $token;
    }, $html) ?? $html;

    $html = preg_replace_callback('~>([^<>]+)<~u', static function (array $m): string {
        return '>' . t($m[1]) . '<';
    }, $html) ?? $html;

    $html = preg_replace_callback('~\\b(placeholder|title|aria-label|alt)=("([^"]*)"|\'([^\']*)\')~i', static function (array $m): string {
        $value = $m[3] !== '' ? $m[3] : ($m[4] ?? '');
        $quote = $m[2][0] ?? '"';
        return $m[1] . '=' . $quote . t($value) . $quote;
    }, $html) ?? $html;

    return $protected ? strtr($html, $protected) : $html;
}

function language_url(string $language): string
{
    $uri = (string)($_SERVER['REQUEST_URI'] ?? '/');
    $parts = parse_url($uri) ?: [];
    $query = [];
    parse_str((string)($parts['query'] ?? ''), $query);
    $query['lang'] = in_array($language, ['id', 'en'], true) ? $language : 'id';
    return (string)($parts['path'] ?? '/') . '?' . http_build_query($query);
}
