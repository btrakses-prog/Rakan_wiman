# Upgrade RAKAN WIMAN v0.4.23

Rilis ini mengubah persyaratan minimum kata sandi administrator dari 12 menjadi 5 karakter.

## Perubahan
- Web Installer: kata sandi Superadmin minimal 5 karakter.
- Setup Superadmin pertama: minimal 5 karakter.
- Penambahan akun Admin / Operator: minimal 5 karakter.
- Penggantian kata sandi administrator: minimal 5 karakter.
- Validasi server menggunakan panjang karakter UTF-8 (`mb_strlen`) dan formulir browser menggunakan `minlength=5`.
- Kata sandi akun yang sudah ada tidak diubah atau di-reset.
- Tidak ada perubahan database atau migration.

## Cara upgrade
1. Cadangkan folder aplikasi dan database.
2. Ekstrak paket v0.4.23.
3. Upload dan timpa file aplikasi. Pertahankan `.env`, `APP_KEY`, dan folder `storage` dari instalasi yang sedang berjalan.
4. Buka kembali aplikasi dan uji perubahan kata sandi menggunakan minimal 5 karakter.

## Catatan keamanan
Batas 5 karakter merupakan kebijakan yang lebih longgar daripada praktik keamanan yang disarankan. Gunakan kata sandi yang lebih panjang dan unik, terutama untuk akun Superadmin yang dapat mengelola router, voucher, dan pembayaran.
