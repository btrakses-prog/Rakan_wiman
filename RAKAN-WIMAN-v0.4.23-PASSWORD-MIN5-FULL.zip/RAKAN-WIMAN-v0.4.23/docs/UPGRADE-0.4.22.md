# Upgrade RAKAN WIMAN v0.4.22

Rilis ini memperbarui tema antarmuka dan menambahkan pilihan Bahasa Indonesia / English. Tidak ada perubahan skema database dan tidak ada migration baru.

## Cara upgrade
1. Cadangkan folder aplikasi dan database terlebih dahulu.
2. Ekstrak arsip rilis ini.
3. Upload dan timpa file aplikasi dari paket, tetapi pertahankan file `.env` dan folder `storage` yang sedang digunakan.
4. Pastikan folder `resources/lang` ikut ter-upload karena berisi kamus English.
5. Untuk captive portal MikroTik, terapkan ulang template `hotspot-template/RakanWiman` melalui fitur ekspor / pengelola template HotSpot agar file `lang.js` dan halaman bilingual ikut tersalin ke router.
6. Buka kembali aplikasi, lalu gunakan pilihan `ID` / `EN` pada bagian kanan atas. Pada portal Wi-Fi, gunakan tombol `ID` / `EN` di kartu login.

## Catatan
- Bahasa default adalah Bahasa Indonesia.
- Pilihan bahasa panel dan portal pembelian disimpan pada sesi browser; captive portal menyimpan pilihan di localStorage browser. Pengaturan ini tidak mengubah data pelanggan, paket, voucher, atau transaksi.
- Tidak diperlukan perubahan konfigurasi MikroTik, ViaQRIS, WhatsApp Gateway, atau cron.
- Untuk instalasi baru, gunakan paket FULL dan ikuti `docs/INSTALL.md`.
